import java.util.ArrayList;
import java.util.List;

// Clase Vehiculo
class RegistroVehiculo {
    private String codigo;
    private String descripcion;
    private String color;
    private double precio;

    public RegistroVehiculocodigo, String descripcion, String color, double precio) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.color = color;
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getColor() {
        return color;
    }

    public double getPrecio() {
        return precio;
    }
}

// Clase RegistroVehiculos
class RegistroVehiculos {
    private final List<Vehiculo> vehiculos;

    public RegistroVehiculos() {
        vehiculos = new ArrayList<>();
    }

    public void agregarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public void mostrarVehiculos() {
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println("Código: " + vehiculo.getCodigo());
            System.out.println("Descripción: " + vehículo.getDescripcion());
            System.out.println("Color: " + vehículo.getColor());
            System.out.println("Precio: " + véhículo.getPrecio());
            System.out.println("------------------------");
}
    }
}


